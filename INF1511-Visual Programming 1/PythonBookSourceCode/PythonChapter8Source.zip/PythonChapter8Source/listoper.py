# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'listoper.ui'
#
# Created: Mon May 30 02:38:25 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(452, 263)
        self.lineEdit = QtGui.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(90, 20, 141, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.DeleteButton = QtGui.QPushButton(Dialog)
        self.DeleteButton.setGeometry(QtCore.QRect(70, 140, 75, 23))
        self.DeleteButton.setObjectName(_fromUtf8("DeleteButton"))
        self.AddButton = QtGui.QPushButton(Dialog)
        self.AddButton.setGeometry(QtCore.QRect(70, 60, 75, 23))
        self.AddButton.setObjectName(_fromUtf8("AddButton"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(30, 20, 51, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.EditButton = QtGui.QPushButton(Dialog)
        self.EditButton.setGeometry(QtCore.QRect(70, 100, 75, 23))
        self.EditButton.setObjectName(_fromUtf8("EditButton"))
        self.DeleteAllButton = QtGui.QPushButton(Dialog)
        self.DeleteAllButton.setGeometry(QtCore.QRect(70, 180, 75, 23))
        self.DeleteAllButton.setObjectName(_fromUtf8("DeleteAllButton"))
        self.listWidget = QtGui.QListWidget(Dialog)
        self.listWidget.setGeometry(QtCore.QRect(250, 20, 191, 221))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.DeleteButton.setText(QtGui.QApplication.translate("Dialog", "Delete", None, QtGui.QApplication.UnicodeUTF8))
        self.AddButton.setText(QtGui.QApplication.translate("Dialog", "Add", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Enter Text", None, QtGui.QApplication.UnicodeUTF8))
        self.EditButton.setText(QtGui.QApplication.translate("Dialog", "Edit", None, QtGui.QApplication.UnicodeUTF8))
        self.DeleteAllButton.setText(QtGui.QApplication.translate("Dialog", "Delete All", None, QtGui.QApplication.UnicodeUTF8))

