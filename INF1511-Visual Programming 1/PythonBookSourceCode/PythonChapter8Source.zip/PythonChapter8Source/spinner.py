# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'spinner.ui'
#
# Created: Mon May 30 00:28:25 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(389, 161)
        self.spinBox = QtGui.QSpinBox(Dialog)
        self.spinBox.setGeometry(QtCore.QRect(140, 10, 42, 22))
        self.spinBox.setObjectName(_fromUtf8("spinBox"))
        self.lineSecondValue = QtGui.QLineEdit(Dialog)
        self.lineSecondValue.setEnabled(False)
        self.lineSecondValue.setGeometry(QtCore.QRect(240, 40, 113, 20))
        self.lineSecondValue.setObjectName(_fromUtf8("lineSecondValue"))
        self.labelAddition = QtGui.QLabel(Dialog)
        self.labelAddition.setGeometry(QtCore.QRect(130, 90, 121, 16))
        self.labelAddition.setText(_fromUtf8(""))
        self.labelAddition.setObjectName(_fromUtf8("labelAddition"))
        self.doubleSpinBox = QtGui.QDoubleSpinBox(Dialog)
        self.doubleSpinBox.setGeometry(QtCore.QRect(140, 40, 62, 22))
        self.doubleSpinBox.setObjectName(_fromUtf8("doubleSpinBox"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(20, 50, 101, 16))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineFirstValue = QtGui.QLineEdit(Dialog)
        self.lineFirstValue.setEnabled(False)
        self.lineFirstValue.setGeometry(QtCore.QRect(240, 10, 113, 20))
        self.lineFirstValue.setObjectName(_fromUtf8("lineFirstValue"))
        self.AddButton = QtGui.QPushButton(Dialog)
        self.AddButton.setGeometry(QtCore.QRect(150, 120, 75, 23))
        self.AddButton.setObjectName(_fromUtf8("AddButton"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 20, 91, 16))
        self.label.setObjectName(_fromUtf8("label"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Select Second value", None, QtGui.QApplication.UnicodeUTF8))
        self.AddButton.setText(QtGui.QApplication.translate("Dialog", "Add", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Select First value", None, QtGui.QApplication.UnicodeUTF8))

