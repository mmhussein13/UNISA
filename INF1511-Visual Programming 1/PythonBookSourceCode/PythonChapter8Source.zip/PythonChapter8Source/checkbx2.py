# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'checkbx2.ui'
#
# Created: Wed Nov  2 13:12:09 2011
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(328, 220)
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(110, 10, 141, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setText(QtGui.QApplication.translate("Dialog", "XYZ Food Corner", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(40, 170, 71, 16))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Total Amount", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineAmount = QtGui.QLineEdit(Dialog)
        self.lineAmount.setEnabled(False)
        self.lineAmount.setGeometry(QtCore.QRect(120, 170, 131, 20))
        self.lineAmount.setObjectName(_fromUtf8("lineAmount"))
        self.checkPizza20 = QtGui.QCheckBox(Dialog)
        self.checkPizza20.setGeometry(QtCore.QRect(110, 40, 91, 17))
        self.checkPizza20.setText(QtGui.QApplication.translate("Dialog", "Pizza   $20", None, QtGui.QApplication.UnicodeUTF8))
        self.checkPizza20.setObjectName(_fromUtf8("checkPizza20"))
        self.checkHotDog5 = QtGui.QCheckBox(Dialog)
        self.checkHotDog5.setGeometry(QtCore.QRect(110, 70, 111, 17))
        self.checkHotDog5.setText(QtGui.QApplication.translate("Dialog", "Hot Dog  $5", None, QtGui.QApplication.UnicodeUTF8))
        self.checkHotDog5.setObjectName(_fromUtf8("checkHotDog5"))
        self.checkFries10 = QtGui.QCheckBox(Dialog)
        self.checkFries10.setGeometry(QtCore.QRect(110, 100, 121, 17))
        self.checkFries10.setText(QtGui.QApplication.translate("Dialog", "French Fries  $10", None, QtGui.QApplication.UnicodeUTF8))
        self.checkFries10.setObjectName(_fromUtf8("checkFries10"))
        self.checkBurger15 = QtGui.QCheckBox(Dialog)
        self.checkBurger15.setGeometry(QtCore.QRect(110, 130, 121, 17))
        self.checkBurger15.setText(QtGui.QApplication.translate("Dialog", "Chicken Burger  $15", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBurger15.setObjectName(_fromUtf8("checkBurger15"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        pass

