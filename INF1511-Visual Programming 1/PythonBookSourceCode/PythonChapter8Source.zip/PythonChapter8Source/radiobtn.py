# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'radiobtn.ui'
#
# Created: Sun May 29 14:33:29 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(430, 448)
        self.labelResult = QtGui.QLabel(Dialog)
        self.labelResult.setGeometry(QtCore.QRect(60, 240, 171, 21))
        self.labelResult.setObjectName(_fromUtf8("labelResult"))
        self.lineSecondNumber = QtGui.QLineEdit(Dialog)
        self.lineSecondNumber.setGeometry(QtCore.QRect(170, 60, 113, 20))
        self.lineSecondNumber.setObjectName(_fromUtf8("lineSecondNumber"))
        self.labelSecondNumber = QtGui.QLabel(Dialog)
        self.labelSecondNumber.setGeometry(QtCore.QRect(50, 60, 111, 16))
        self.labelSecondNumber.setObjectName(_fromUtf8("labelSecondNumber"))
        self.labelFirstNumber = QtGui.QLabel(Dialog)
        self.labelFirstNumber.setGeometry(QtCore.QRect(60, 30, 101, 16))
        self.labelFirstNumber.setObjectName(_fromUtf8("labelFirstNumber"))
        self.ComputeButton = QtGui.QPushButton(Dialog)
        self.ComputeButton.setGeometry(QtCore.QRect(180, 280, 75, 23))
        self.ComputeButton.setObjectName(_fromUtf8("ComputeButton"))
        self.radioAdd = QtGui.QRadioButton(Dialog)
        self.radioAdd.setGeometry(QtCore.QRect(60, 110, 82, 17))
        self.radioAdd.setObjectName(_fromUtf8("radioAdd"))
        self.radioDivide = QtGui.QRadioButton(Dialog)
        self.radioDivide.setGeometry(QtCore.QRect(60, 200, 82, 17))
        self.radioDivide.setObjectName(_fromUtf8("radioDivide"))
        self.radioSubtract = QtGui.QRadioButton(Dialog)
        self.radioSubtract.setGeometry(QtCore.QRect(60, 140, 82, 17))
        self.radioSubtract.setObjectName(_fromUtf8("radioSubtract"))
        self.radioMultiply = QtGui.QRadioButton(Dialog)
        self.radioMultiply.setGeometry(QtCore.QRect(60, 170, 82, 17))
        self.radioMultiply.setObjectName(_fromUtf8("radioMultiply"))
        self.lineFirstNumber = QtGui.QLineEdit(Dialog)
        self.lineFirstNumber.setGeometry(QtCore.QRect(170, 30, 113, 20))
        self.lineFirstNumber.setObjectName(_fromUtf8("lineFirstNumber"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.labelResult.setText(QtGui.QApplication.translate("Dialog", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.labelSecondNumber.setText(QtGui.QApplication.translate("Dialog", "Enter Second Number", None, QtGui.QApplication.UnicodeUTF8))
        self.labelFirstNumber.setText(QtGui.QApplication.translate("Dialog", "Enter First Number", None, QtGui.QApplication.UnicodeUTF8))
        self.ComputeButton.setText(QtGui.QApplication.translate("Dialog", "Compute", None, QtGui.QApplication.UnicodeUTF8))
        self.radioAdd.setText(QtGui.QApplication.translate("Dialog", "Add", None, QtGui.QApplication.UnicodeUTF8))
        self.radioDivide.setText(QtGui.QApplication.translate("Dialog", "Divide", None, QtGui.QApplication.UnicodeUTF8))
        self.radioSubtract.setText(QtGui.QApplication.translate("Dialog", "Subtract", None, QtGui.QApplication.UnicodeUTF8))
        self.radioMultiply.setText(QtGui.QApplication.translate("Dialog", "Multiply", None, QtGui.QApplication.UnicodeUTF8))

