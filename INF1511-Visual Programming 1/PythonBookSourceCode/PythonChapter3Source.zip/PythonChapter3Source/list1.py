names=['John', 'Kelly', 'Caroline', 'Paula']
print (names[0])
print (names[-1])
