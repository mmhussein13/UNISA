s="Hello World!"
print ("Original String is ", s)
print('String after toggling the case: ', s.swapcase())
print ("String in upper case is ", s.upper())
if (s.istitle()):
	print("String in lower case is ", s.lower())
print("String, ", s, " is in tite case :", s.istitle())
print ("String in capitalize form is ", s.capitalize())
