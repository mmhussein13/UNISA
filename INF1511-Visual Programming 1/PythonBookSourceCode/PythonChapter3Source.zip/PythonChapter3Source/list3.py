names=['John', 'Kelly', 'Caroline', 'Paula']
for n in names:
	print (n)
