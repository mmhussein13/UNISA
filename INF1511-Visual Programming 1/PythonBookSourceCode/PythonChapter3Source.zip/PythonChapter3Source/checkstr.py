m=input("Enter a string: ")
n=input("Enter a sub string: ")
if n in m: 	
	print (n, "is found in the string ", m)
else:
	print (n,"does not exists in the string ", m)