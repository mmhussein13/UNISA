p=input("Enter a string: ")
q=input("Enter another string: ")
print ("The first string is: ", p)
print ("The second string is: ", q)
print ("The combination is ", p.join(q))

