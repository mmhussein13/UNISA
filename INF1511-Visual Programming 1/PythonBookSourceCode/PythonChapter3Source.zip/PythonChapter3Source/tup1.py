names=('John', 'Kelly', 'Caroline', 'Steve', 'Katheline')
print ("The names in the tuple are: ", names)
print ("The first name in the tuple is ", names[0])
print ("The last name in the tuple is ", names[len(names)-1])
print ("The names in the tuple are ")
for n in names:
	print (n)
