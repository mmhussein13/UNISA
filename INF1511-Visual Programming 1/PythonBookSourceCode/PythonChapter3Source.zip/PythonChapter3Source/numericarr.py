p= [ 0 for i in range(5) ]  

print ("Enter five numerical")
for i in range(5):
		p[i]= int(input())
print ("Numerical entered in the array are ", p)
print ("Numerical entered in the array are ")
for n in p:
	print (n)
