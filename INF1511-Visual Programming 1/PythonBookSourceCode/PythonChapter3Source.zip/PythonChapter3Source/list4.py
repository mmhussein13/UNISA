names=['John', 'Kelly', 'Caroline', 'Paula']
n=input("Enter  a name: ")
if n in names:
	print ("Entered name is present in the list")
else:
	print ("Sorry the entered name is not in the list")
