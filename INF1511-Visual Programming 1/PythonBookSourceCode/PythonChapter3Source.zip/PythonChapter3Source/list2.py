names=['John', 'Kelly', 'Caroline', 'Paula']
for i in range(0,len(names)):
	print (names[i])
