p=input("Enter a sentence: ")
print ("The sentence entered is: ", p)
print ("The words in the sentence are ")
print (p.split())
