m=input("Enter marks: ")
if m.isdigit():
	print ("Entered data is numeric")
else:
        print ("Entered data is not numeric")
