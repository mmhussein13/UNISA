s=input("Enter a sentence: ")
print ('The original sentence is: ', s)
if s.endswith('today'):
	print('The entered sentence ends with the word today')
if s.endswith('today', 8, 13):
	print('The entered sentence ends with the word today')
if s.startswith('Its'):
	print('The entered sentence begins with the word Its')
if s.startswith('Its', 0, 3):
	print('The entered sentence begins with the word Its')
print('The string after toggling the case: ', s.swapcase())
t="#"
print('The sentence after joining character # to the sentence: ', t.join(s))
t="hello"
print('The sentence after joining word, hello to the sentence: ', t.join(s))
