s="Hello World!"
t="Nice Day"
print  (s+t)
print (s+" "+t)
print (s*3)
u="#"
print('The string after joining character # to the string ', t,' : ', u.join(t))
u="hello"
print('The string after joining word, hello to the string ',t,' : ', u.join(t))
