n=input("Enter your name: ")
l=len(n)
print ("The name entered is ", n, " and its length is ", l)
