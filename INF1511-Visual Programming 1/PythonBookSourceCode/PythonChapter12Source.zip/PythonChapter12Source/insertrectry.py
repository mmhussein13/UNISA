import sys
import MySQLdb
try:
    conn=MySQLdb.connect(host="localhost", user="root", passwd="mce", db="shopping")
except MySQLdb.Error:
    print ("Error in establishing connection")
    sys.exit(1)    
cursor=conn.cursor()
try:
    cursor.execute("""
    INSERT INTO products (prod_id, prod_name, quantity, price)
    VALUES (101, 'Camera', 100, 15)
    """)
    conn.commit()
    print('One row inserted into the products table')
except:
    conn.rollback()
cursor.close()
conn.close()
 
