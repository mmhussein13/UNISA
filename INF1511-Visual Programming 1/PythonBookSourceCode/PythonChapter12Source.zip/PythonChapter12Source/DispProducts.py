# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'DispProducts.ui'
#
# Created: Wed Feb 16 18:07:34 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(420, 194)
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(140, 10, 131, 16))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setWeight(75)
        font.setBold(True)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(30, 40, 51, 16))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(190, 40, 71, 16))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_4 = QtGui.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(40, 70, 46, 13))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_5 = QtGui.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(230, 70, 31, 16))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.FirstButton = QtGui.QPushButton(Dialog)
        self.FirstButton.setGeometry(QtCore.QRect(20, 130, 75, 23))
        self.FirstButton.setObjectName(_fromUtf8("FirstButton"))
        self.PreviousButton = QtGui.QPushButton(Dialog)
        self.PreviousButton.setGeometry(QtCore.QRect(120, 130, 75, 23))
        self.PreviousButton.setObjectName(_fromUtf8("PreviousButton"))
        self.NextButton = QtGui.QPushButton(Dialog)
        self.NextButton.setGeometry(QtCore.QRect(220, 130, 75, 23))
        self.NextButton.setObjectName(_fromUtf8("NextButton"))
        self.LastButton = QtGui.QPushButton(Dialog)
        self.LastButton.setGeometry(QtCore.QRect(320, 130, 75, 23))
        self.LastButton.setObjectName(_fromUtf8("LastButton"))
        self.prodid = QtGui.QLineEdit(Dialog)
        self.prodid.setGeometry(QtCore.QRect(90, 40, 71, 20))
        self.prodid.setObjectName(_fromUtf8("prodid"))
        self.prodname = QtGui.QLineEdit(Dialog)
        self.prodname.setGeometry(QtCore.QRect(270, 40, 131, 20))
        self.prodname.setObjectName(_fromUtf8("prodname"))
        self.qty = QtGui.QLineEdit(Dialog)
        self.qty.setGeometry(QtCore.QRect(90, 70, 51, 20))
        self.qty.setObjectName(_fromUtf8("qty"))
        self.price = QtGui.QLineEdit(Dialog)
        self.price.setGeometry(QtCore.QRect(270, 70, 61, 20))
        self.price.setObjectName(_fromUtf8("price"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "List of Products", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Product ID", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("Dialog", "Product Name", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Dialog", "Quantity", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("Dialog", "Price", None, QtGui.QApplication.UnicodeUTF8))
        self.FirstButton.setText(QtGui.QApplication.translate("Dialog", "First", None, QtGui.QApplication.UnicodeUTF8))
        self.PreviousButton.setText(QtGui.QApplication.translate("Dialog", "Previous", None, QtGui.QApplication.UnicodeUTF8))
        self.NextButton.setText(QtGui.QApplication.translate("Dialog", "Next", None, QtGui.QApplication.UnicodeUTF8))
        self.LastButton.setText(QtGui.QApplication.translate("Dialog", "Last", None, QtGui.QApplication.UnicodeUTF8))

