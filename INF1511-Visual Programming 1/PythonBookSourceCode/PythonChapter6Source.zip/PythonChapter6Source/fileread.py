f = open('aboutbook.txt', 'r') 
lines = f.read()
print (lines) 
f.close()
