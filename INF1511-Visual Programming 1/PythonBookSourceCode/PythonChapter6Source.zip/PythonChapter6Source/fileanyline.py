import linecache
line=linecache.getline('aboutbook.txt', 3)
print ('The content of third line are:', line)
