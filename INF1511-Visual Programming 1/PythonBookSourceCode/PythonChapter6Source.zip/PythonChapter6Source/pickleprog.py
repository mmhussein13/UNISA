import pickle

class rect: 
	def __init__(self, x,y):
		self.l = x
		self.b = y
	def rectarea(self):
		return "Area of rectangle is ", self.l * self.b
r=rect(5,8)

f = open('studentinfo.txt', 'wb')
pickle.dump(r, f) 
f.close()
del r
f = open('studentinfo.txt','rb')
storedobj = pickle.load(f)
print (storedobj.rectarea())
