n=int(input('Enter a positive value: '))
assert(n >=0), "Entered value is not a positive value"
