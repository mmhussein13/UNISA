import sys
f = open('aboutbook.txt', 'r') 
lines = f.readlines()
f.close()
print('The content in the file are: ', lines)
print('\nThe content in the file are: ')
for line in lines:
       sys.stdout.write(line)
print('\n\nThe content in the file are ')
for i in range(0, len(lines)):
	sys.stdout.write(lines[i])
