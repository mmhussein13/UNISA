# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'buddytab.ui'
#
# Created: Tue Mar 01 19:23:04 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(490, 182)
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(10, 20, 91, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.quantity = QtGui.QLineEdit(Dialog)
        self.quantity.setGeometry(QtCore.QRect(120, 10, 113, 20))
        self.quantity.setObjectName(_fromUtf8("quantity"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(280, 10, 71, 16))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.rate = QtGui.QLineEdit(Dialog)
        self.rate.setGeometry(QtCore.QRect(370, 10, 113, 20))
        self.rate.setObjectName(_fromUtf8("rate"))
        self.label_3 = QtGui.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(10, 50, 101, 16))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.discount = QtGui.QLineEdit(Dialog)
        self.discount.setGeometry(QtCore.QRect(130, 50, 113, 20))
        self.discount.setObjectName(_fromUtf8("discount"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(120, 100, 111, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.result = QtGui.QLabel(Dialog)
        self.result.setGeometry(QtCore.QRect(50, 140, 351, 16))
        self.result.setText(_fromUtf8(""))
        self.result.setObjectName(_fromUtf8("result"))
        self.label.setBuddy(self.quantity)
        self.label_2.setBuddy(self.rate)
        self.label_3.setBuddy(self.discount)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setTabOrder(self.quantity, self.discount)
        Dialog.setTabOrder(self.discount, self.rate)
        Dialog.setTabOrder(self.rate, self.pushButton)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "&Number of items", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "&Price per item", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("Dialog", "&Discount Percentage", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setText(QtGui.QApplication.translate("Dialog", "Calculate Amount", None, QtGui.QApplication.UnicodeUTF8))

