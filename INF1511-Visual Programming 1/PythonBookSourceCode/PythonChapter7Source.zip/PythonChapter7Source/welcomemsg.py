# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'welcomemsg.ui'
#
# Created: Sun May 29 10:51:37 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(400, 300)
        self.ClickMeButton = QtGui.QPushButton(Dialog)
        self.ClickMeButton.setGeometry(QtCore.QRect(150, 120, 75, 23))
        self.ClickMeButton.setObjectName(_fromUtf8("ClickMeButton"))
        self.labelEnterName = QtGui.QLabel(Dialog)
        self.labelEnterName.setGeometry(QtCore.QRect(30, 30, 101, 21))
        self.labelEnterName.setObjectName(_fromUtf8("labelEnterName"))
        self.labelMessage = QtGui.QLabel(Dialog)
        self.labelMessage.setGeometry(QtCore.QRect(120, 75, 161, 21))
        self.labelMessage.setText(_fromUtf8(""))
        self.labelMessage.setObjectName(_fromUtf8("labelMessage"))
        self.lineUserName = QtGui.QLineEdit(Dialog)
        self.lineUserName.setGeometry(QtCore.QRect(130, 30, 181, 20))
        self.lineUserName.setObjectName(_fromUtf8("lineUserName"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.ClickMeButton.setText(QtGui.QApplication.translate("Dialog", "Click Me", None, QtGui.QApplication.UnicodeUTF8))
        self.labelEnterName.setText(QtGui.QApplication.translate("Dialog", "Enter your name", None, QtGui.QApplication.UnicodeUTF8))

