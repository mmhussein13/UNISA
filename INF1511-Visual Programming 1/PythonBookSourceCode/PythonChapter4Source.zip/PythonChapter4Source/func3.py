def quantity():
	return 10 

print (quantity())
q=quantity()
print (q)
