import calendar

year = int(input("Type in the year number:"))
calendar.prcal(year)
