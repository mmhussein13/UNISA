import sys, calendar

print("The list of methods and attributes in the local scope: ",dir())
print ("\nThe list of methods and attributes in the calendar module: ", dir(calendar)) 
print ("\nThe list of methods and attributes in the sys module: ", dir(sys)) 
