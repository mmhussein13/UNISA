def compute(x):
	x += 5 
	print ("Value of x in function is ", x)
	return None


x=10
compute(x)
print ("Value of x is still ", x)
