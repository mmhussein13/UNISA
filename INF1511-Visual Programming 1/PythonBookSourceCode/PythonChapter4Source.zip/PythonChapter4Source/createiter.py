names=['John', 'Kelly', 'Caroline', 'Paula']
i = iter(names)
print (i.__next__())
print (i.__next__())
print (i.__next__())
print (i.__next__())
print (i.__next__())

 
