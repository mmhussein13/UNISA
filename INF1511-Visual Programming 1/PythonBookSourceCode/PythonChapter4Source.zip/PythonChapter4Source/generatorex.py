def fruits(seq):
	for fruit in seq: 
		yield '%s' % fruit 


f=fruits(['Apple', 'Orange', 'Mango', 'Banana'])
print ('The list of fruits are :')
print (f.__next__())
print (f.__next__())
print (f.__next__())
print (f.__next__())
f=fruits(['Apple', 'Orange', 'Mango', 'Banana'])
print ('The list of fruits are :')
for x in f: 
	print (x)
