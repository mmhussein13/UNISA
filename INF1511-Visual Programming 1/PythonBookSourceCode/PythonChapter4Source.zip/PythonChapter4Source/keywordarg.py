def volume(l, b=5, h=10): 
    print ('l is', l, ' and b is', b, ' and h is', h, ' and volume is ', l*b*h)

volume(2, 4) 
volume(3, h=6) 
volume(h=7, l=2)
