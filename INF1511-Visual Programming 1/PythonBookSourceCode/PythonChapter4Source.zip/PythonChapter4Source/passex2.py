def conv(x):
	if x==0:
		pass	if x==1:		return "one"	if x==2:		return "two"	if x==3:		return "three"	if x==4:		return "four"print (conv(2))print (conv(0))