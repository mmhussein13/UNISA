def rect(l,b): 
	'''Computes the area of rectangle

	Values for length and breadth are passed to the function for computation'''
	print ('Area of rectangle is ', l*b)	

rect(5,8)
print (rect.__doc__)
