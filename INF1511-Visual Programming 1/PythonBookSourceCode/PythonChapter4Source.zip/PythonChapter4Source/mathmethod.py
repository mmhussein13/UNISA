import math 
print (math.ceil(7.3)) 
print (math.ceil(-7.3)) 
print (math.floor(7.9)) 
print (math.floor(-7.9)) 
