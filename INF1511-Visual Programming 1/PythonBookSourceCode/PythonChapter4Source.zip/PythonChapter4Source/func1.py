def sum(a, b):	
	return a + b

k=sum(10,20)
print ("Sum is", k)
