def sum(x, y=10): 
	return x+y 

print (sum(10))
print (sum(5,8))
