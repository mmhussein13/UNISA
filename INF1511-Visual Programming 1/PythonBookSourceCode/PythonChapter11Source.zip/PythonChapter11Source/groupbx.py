# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'groupbx.ui'
#
# Created: Wed Nov  2 13:15:06 2011
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(419, 291)
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.layoutWidget = QtGui.QWidget(Dialog)
        self.layoutWidget.setGeometry(QtCore.QRect(20, 10, 311, 271))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.IceCreamBox = QtGui.QGroupBox(self.layoutWidget)
        self.IceCreamBox.setTitle(QtGui.QApplication.translate("Dialog", "Ice Creams", None, QtGui.QApplication.UnicodeUTF8))
        self.IceCreamBox.setObjectName(_fromUtf8("IceCreamBox"))
        self.vanila = QtGui.QRadioButton(self.IceCreamBox)
        self.vanila.setGeometry(QtCore.QRect(20, 20, 131, 17))
        self.vanila.setText(QtGui.QApplication.translate("Dialog", "Plain Vanilla  $5", None, QtGui.QApplication.UnicodeUTF8))
        self.vanila.setObjectName(_fromUtf8("vanila"))
        self.blacksunday = QtGui.QRadioButton(self.IceCreamBox)
        self.blacksunday.setGeometry(QtCore.QRect(20, 50, 121, 17))
        self.blacksunday.setText(QtGui.QApplication.translate("Dialog", "Black Sunday $10", None, QtGui.QApplication.UnicodeUTF8))
        self.blacksunday.setObjectName(_fromUtf8("blacksunday"))
        self.chocolatechips = QtGui.QRadioButton(self.IceCreamBox)
        self.chocolatechips.setGeometry(QtCore.QRect(20, 80, 141, 17))
        self.chocolatechips.setText(QtGui.QApplication.translate("Dialog", "Chocolate Chips  $20", None, QtGui.QApplication.UnicodeUTF8))
        self.chocolatechips.setObjectName(_fromUtf8("chocolatechips"))
        self.strawberry = QtGui.QRadioButton(self.IceCreamBox)
        self.strawberry.setGeometry(QtCore.QRect(20, 110, 121, 17))
        self.strawberry.setText(QtGui.QApplication.translate("Dialog", "Strawberry  $15 ", None, QtGui.QApplication.UnicodeUTF8))
        self.strawberry.setObjectName(_fromUtf8("strawberry"))
        self.verticalLayout.addWidget(self.IceCreamBox)
        self.DrinksBox = QtGui.QGroupBox(self.layoutWidget)
        self.DrinksBox.setTitle(QtGui.QApplication.translate("Dialog", "Drinks", None, QtGui.QApplication.UnicodeUTF8))
        self.DrinksBox.setCheckable(True)
        self.DrinksBox.setObjectName(_fromUtf8("DrinksBox"))
        self.coffee = QtGui.QRadioButton(self.DrinksBox)
        self.coffee.setGeometry(QtCore.QRect(30, 30, 82, 17))
        self.coffee.setText(QtGui.QApplication.translate("Dialog", "Coffee  $5", None, QtGui.QApplication.UnicodeUTF8))
        self.coffee.setObjectName(_fromUtf8("coffee"))
        self.colddrink = QtGui.QRadioButton(self.DrinksBox)
        self.colddrink.setGeometry(QtCore.QRect(30, 60, 101, 17))
        self.colddrink.setText(QtGui.QApplication.translate("Dialog", "Cold Drink $10", None, QtGui.QApplication.UnicodeUTF8))
        self.colddrink.setObjectName(_fromUtf8("colddrink"))
        self.juice = QtGui.QRadioButton(self.DrinksBox)
        self.juice.setGeometry(QtCore.QRect(30, 90, 82, 17))
        self.juice.setText(QtGui.QApplication.translate("Dialog", "Juice $15", None, QtGui.QApplication.UnicodeUTF8))
        self.juice.setObjectName(_fromUtf8("juice"))
        self.verticalLayout.addWidget(self.DrinksBox)
        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 4, 1)
        spacerItem = QtGui.QSpacerItem(20, 168, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 0, 1, 1, 1)
        self.label = QtGui.QLabel(self.layoutWidget)
        self.label.setText(_fromUtf8(""))
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 1, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 18, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 2, 1, 1, 1)
        self.CalculateButton = QtGui.QPushButton(self.layoutWidget)
        self.CalculateButton.setText(QtGui.QApplication.translate("Dialog", "Calculate Bill", None, QtGui.QApplication.UnicodeUTF8))
        self.CalculateButton.setObjectName(_fromUtf8("CalculateButton"))
        self.gridLayout.addWidget(self.CalculateButton, 3, 1, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        pass

