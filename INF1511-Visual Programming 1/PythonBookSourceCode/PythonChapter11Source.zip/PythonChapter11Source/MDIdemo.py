# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mdidemo.ui'
#
# Created: Wed Nov  2 13:14:18 2011
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(775, 600)
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.showNext = QtGui.QPushButton(self.centralwidget)
        self.showNext.setGeometry(QtCore.QRect(50, 430, 75, 23))
        self.showNext.setText(QtGui.QApplication.translate("MainWindow", "Show Next", None, QtGui.QApplication.UnicodeUTF8))
        self.showNext.setObjectName(_fromUtf8("showNext"))
        self.cascadeButton = QtGui.QPushButton(self.centralwidget)
        self.cascadeButton.setGeometry(QtCore.QRect(50, 470, 75, 23))
        self.cascadeButton.setText(QtGui.QApplication.translate("MainWindow", "Cascade", None, QtGui.QApplication.UnicodeUTF8))
        self.cascadeButton.setObjectName(_fromUtf8("cascadeButton"))
        self.SubWindowViewButton = QtGui.QPushButton(self.centralwidget)
        self.SubWindowViewButton.setGeometry(QtCore.QRect(200, 470, 101, 23))
        self.SubWindowViewButton.setText(QtGui.QApplication.translate("MainWindow", "SubWindow View", None, QtGui.QApplication.UnicodeUTF8))
        self.SubWindowViewButton.setObjectName(_fromUtf8("SubWindowViewButton"))
        self.closeAll = QtGui.QPushButton(self.centralwidget)
        self.closeAll.setGeometry(QtCore.QRect(300, 430, 75, 23))
        self.closeAll.setText(QtGui.QApplication.translate("MainWindow", "Close All", None, QtGui.QApplication.UnicodeUTF8))
        self.closeAll.setObjectName(_fromUtf8("closeAll"))
        self.tileButton = QtGui.QPushButton(self.centralwidget)
        self.tileButton.setGeometry(QtCore.QRect(140, 470, 41, 23))
        self.tileButton.setText(QtGui.QApplication.translate("MainWindow", "Tile", None, QtGui.QApplication.UnicodeUTF8))
        self.tileButton.setObjectName(_fromUtf8("tileButton"))
        self.mdiArea = QtGui.QMdiArea(self.centralwidget)
        self.mdiArea.setGeometry(QtCore.QRect(50, 20, 331, 401))
        self.mdiArea.setObjectName(_fromUtf8("mdiArea"))
        self.subwindow = QtGui.QWidget()
        self.subwindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "Subwindow", None, QtGui.QApplication.UnicodeUTF8))
        self.subwindow.setObjectName(_fromUtf8("subwindow"))
        self.label = QtGui.QLabel(self.subwindow)
        self.label.setGeometry(QtCore.QRect(80, 10, 111, 16))
        self.label.setText(QtGui.QApplication.translate("MainWindow", "Enter your views here", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setObjectName(_fromUtf8("label"))
        self.textEdit = QtGui.QTextEdit(self.subwindow)
        self.textEdit.setGeometry(QtCore.QRect(20, 40, 231, 91))
        self.textEdit.setObjectName(_fromUtf8("textEdit"))
        self.subwindow_2 = QtGui.QWidget()
        self.subwindow_2.setWindowTitle(QtGui.QApplication.translate("MainWindow", "Subwindow", None, QtGui.QApplication.UnicodeUTF8))
        self.subwindow_2.setObjectName(_fromUtf8("subwindow_2"))
        self.label_2 = QtGui.QLabel(self.subwindow_2)
        self.label_2.setGeometry(QtCore.QRect(60, 20, 141, 16))
        self.label_2.setText(QtGui.QApplication.translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">This is second Sub Window</span></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.showPrevious = QtGui.QPushButton(self.centralwidget)
        self.showPrevious.setGeometry(QtCore.QRect(170, 430, 91, 23))
        self.showPrevious.setText(QtGui.QApplication.translate("MainWindow", "Show Previous", None, QtGui.QApplication.UnicodeUTF8))
        self.showPrevious.setObjectName(_fromUtf8("showPrevious"))
        self.TabbedViewButton = QtGui.QPushButton(self.centralwidget)
        self.TabbedViewButton.setGeometry(QtCore.QRect(320, 470, 75, 23))
        self.TabbedViewButton.setText(QtGui.QApplication.translate("MainWindow", "Tabbed View", None, QtGui.QApplication.UnicodeUTF8))
        self.TabbedViewButton.setObjectName(_fromUtf8("TabbedViewButton"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 775, 21))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        self.menuWindows = QtGui.QMenu(self.menubar)
        self.menuWindows.setTitle(QtGui.QApplication.translate("MainWindow", "Windows", None, QtGui.QApplication.UnicodeUTF8))
        self.menuWindows.setObjectName(_fromUtf8("menuWindows"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)
        self.actionFirst_Window = QtGui.QAction(MainWindow)
        self.actionFirst_Window.setText(QtGui.QApplication.translate("MainWindow", "First Window", None, QtGui.QApplication.UnicodeUTF8))
        self.actionFirst_Window.setObjectName(_fromUtf8("actionFirst_Window"))
        self.actionSecond_Window = QtGui.QAction(MainWindow)
        self.actionSecond_Window.setText(QtGui.QApplication.translate("MainWindow", "Second Window", None, QtGui.QApplication.UnicodeUTF8))
        self.actionSecond_Window.setObjectName(_fromUtf8("actionSecond_Window"))
        self.menuWindows.addAction(self.actionFirst_Window)
        self.menuWindows.addAction(self.actionSecond_Window)
        self.menubar.addAction(self.menuWindows.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        pass

