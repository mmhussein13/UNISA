l=8
b=5
a=l*b
print ("Area of rectangle is ", a)
