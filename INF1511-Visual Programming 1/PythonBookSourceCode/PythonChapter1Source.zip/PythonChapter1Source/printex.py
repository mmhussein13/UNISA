print (10)
print('Hello World! \
Its hot today \
Lets party')
print('''Hello World!
Its hot today
Lets party''')




