from __future__ import division

r=3
pi=22/7
v=4/3*pi*pow(r,3)
print ("Volume of sphere is %.2f" %v)

