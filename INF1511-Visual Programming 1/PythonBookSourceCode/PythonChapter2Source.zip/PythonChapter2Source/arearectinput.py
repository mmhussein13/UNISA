l=input("Enter length: ")
b=input("Enter breadth: ")
a=int(l)*int(b)
print ("Area of rectangle is",a)
