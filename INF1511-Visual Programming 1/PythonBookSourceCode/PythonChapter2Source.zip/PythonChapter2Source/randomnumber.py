from random import  choice
k=choice(range(1,10))
print ("Random number is ",k)
