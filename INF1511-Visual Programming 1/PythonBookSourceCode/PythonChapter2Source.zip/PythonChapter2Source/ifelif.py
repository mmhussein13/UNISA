m=int(input("Enter marks: "))
if(m >=60):
	print ("First Division")
elif (m >=45):
	print ("Second Division")
else:
	print ("Third Division")