k=1while k <=10 :	if k==7:
		pass
	else:
		print (k)	k+=1