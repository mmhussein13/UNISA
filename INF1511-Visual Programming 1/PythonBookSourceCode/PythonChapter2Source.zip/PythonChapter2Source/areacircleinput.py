from math import pi
r=int(input("Enter radius: "))
a=pi*r*r
print ("Area of the circle is ", a)
print ("Area of the circle is %.2f" %a)
