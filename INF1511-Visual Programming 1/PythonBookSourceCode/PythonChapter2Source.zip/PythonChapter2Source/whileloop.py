k=1
while k <=10 :
	print (k)
	k=k+1

