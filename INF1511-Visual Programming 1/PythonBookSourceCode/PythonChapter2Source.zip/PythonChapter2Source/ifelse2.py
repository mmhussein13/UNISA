m=int(input("Enter marks: "))
if(m >=60):
	print ("First Division")
else:
	if(m >=45):
		print ("Second Division")
	else:
		print ("Third Division")
