k=1
while 1 :
	print (k)
	k=k+1
	if(k>10):
		break
