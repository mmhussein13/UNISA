m=int(input("Enter marks: "))
if(m >=60):
	print ("First Division")
else:
	print ("Second Division")
