from __future__ import division
p=q=r=10
a=(p+q+r)/3
print ("Average of three variables is ", a)
