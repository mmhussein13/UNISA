m=int(input("Enter a number between 1 and 10: "))
if 1<= m <=10: 	
	print ("Number is within range")
else:
	print ("Number is out of range")
