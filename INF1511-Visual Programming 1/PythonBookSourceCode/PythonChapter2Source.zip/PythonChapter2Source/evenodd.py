m=int(input("Enter a number "))
n = m%2
if n ==0: 	
	print ("Number is even")
else:
	print ("Number is odd")