a=10
b=7
c=a&b
d=a ^ b
e= a | b
f=~a
print ('The result of 10 and 7 operation is ', c)
print ('The result of 10 exclusive or 7 operation is ', d)
print ('The result of 10 or 7 operation is ', e)
print ('Bitwise complement of 10 is ', f)
g=a<<2
print ('Left shifting - Multiplying 10 by 4 becomes: ', g)
h=a>>1
print ('Right shifting - Dividing 10 by 2 becomes: ',h)
