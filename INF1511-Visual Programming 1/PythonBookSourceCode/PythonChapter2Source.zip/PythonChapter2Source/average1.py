p=q=r=10
a=1.0/3.0*(p+q+r)
print ("Average of three variables is ", a)
print ("Average of three variables is %.2f" %a)
print ("Average of three variables is %d" %a)
