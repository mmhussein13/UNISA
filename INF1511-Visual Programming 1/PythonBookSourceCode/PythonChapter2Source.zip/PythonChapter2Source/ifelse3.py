m=int(input("Enter marks: "))
if(m >=60):
	print ("First Division")
if(m >=45 and m<60):
	print ("Second Division")
if (m<45):
	print ("Third Division")
