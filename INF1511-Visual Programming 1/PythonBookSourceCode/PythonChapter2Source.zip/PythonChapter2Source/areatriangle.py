b=17
h=13
a=1.0/2.0*b*h
print ("Area of triangle is ", a)
print ("Base= %d, Height is %d, Area of triangle is %f" %(b,h,a))
