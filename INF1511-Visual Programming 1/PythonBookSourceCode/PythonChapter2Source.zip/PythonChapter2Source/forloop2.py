print ("Odd numbers between 1 and 10 are:")
for i in range(1,11,2):
	print (i)
