# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'toolbardemo.ui'
#
# Created: Sun Jan 23 14:22:24 2011
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(800, 600)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(50, 30, 291, 16))
        self.label.setObjectName(_fromUtf8("label"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 20))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)
        self.toolBar = QtGui.QToolBar(MainWindow)
        self.toolBar.setObjectName(_fromUtf8("toolBar"))
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)
        self.actionPlus = QtGui.QAction(MainWindow)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("plus.ICO")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.actionPlus.setIcon(icon)
        self.actionPlus.setObjectName(_fromUtf8("actionPlus"))
        self.actionMinus = QtGui.QAction(MainWindow)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(_fromUtf8("minus.ICO")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.actionMinus.setIcon(icon1)
        self.actionMinus.setObjectName(_fromUtf8("actionMinus"))
        self.actionMultiply = QtGui.QAction(MainWindow)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(_fromUtf8("multiply.ICO")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.actionMultiply.setIcon(icon2)
        self.actionMultiply.setObjectName(_fromUtf8("actionMultiply"))
        self.actionDivide = QtGui.QAction(MainWindow)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(_fromUtf8("divide.ICO")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.actionDivide.setIcon(icon3)
        self.actionDivide.setObjectName(_fromUtf8("actionDivide"))
        self.actionEqual = QtGui.QAction(MainWindow)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(_fromUtf8("equal.ICO")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.actionEqual.setIcon(icon4)
        self.actionEqual.setObjectName(_fromUtf8("actionEqual"))
        self.toolBar.addAction(self.actionPlus)
        self.toolBar.addAction(self.actionMinus)
        self.toolBar.addAction(self.actionMultiply)
        self.toolBar.addAction(self.actionDivide)
        self.toolBar.addAction(self.actionEqual)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("MainWindow", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.toolBar.setWindowTitle(QtGui.QApplication.translate("MainWindow", "toolBar", None, QtGui.QApplication.UnicodeUTF8))
        self.actionPlus.setText(QtGui.QApplication.translate("MainWindow", "Plus", None, QtGui.QApplication.UnicodeUTF8))
        self.actionPlus.setToolTip(QtGui.QApplication.translate("MainWindow", "Plus", None, QtGui.QApplication.UnicodeUTF8))
        self.actionMinus.setText(QtGui.QApplication.translate("MainWindow", "Minus", None, QtGui.QApplication.UnicodeUTF8))
        self.actionMinus.setToolTip(QtGui.QApplication.translate("MainWindow", "Minus", None, QtGui.QApplication.UnicodeUTF8))
        self.actionMultiply.setText(QtGui.QApplication.translate("MainWindow", "Multiply", None, QtGui.QApplication.UnicodeUTF8))
        self.actionMultiply.setToolTip(QtGui.QApplication.translate("MainWindow", "Multiply", None, QtGui.QApplication.UnicodeUTF8))
        self.actionDivide.setText(QtGui.QApplication.translate("MainWindow", "Divide", None, QtGui.QApplication.UnicodeUTF8))
        self.actionDivide.setToolTip(QtGui.QApplication.translate("MainWindow", "Divide", None, QtGui.QApplication.UnicodeUTF8))
        self.actionEqual.setText(QtGui.QApplication.translate("MainWindow", "Equal", None, QtGui.QApplication.UnicodeUTF8))
        self.actionEqual.setToolTip(QtGui.QApplication.translate("MainWindow", "Equal", None, QtGui.QApplication.UnicodeUTF8))

