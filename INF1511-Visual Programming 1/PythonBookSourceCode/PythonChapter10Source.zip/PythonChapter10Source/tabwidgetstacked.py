# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'tabwidgetstacked.ui'
#
# Created: Wed Nov  2 13:13:36 2011
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(307, 269)
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.stackedWidget = QtGui.QStackedWidget(Dialog)
        self.stackedWidget.setGeometry(QtCore.QRect(20, 80, 261, 151))
        self.stackedWidget.setStyleSheet(_fromUtf8("background-color: rgb(170, 255, 255);\n"
"font: 75 10pt \"MS Shell Dlg 2\";"))
        self.stackedWidget.setObjectName(_fromUtf8("stackedWidget"))
        self.stackedWidgetPage1 = QtGui.QWidget()
        self.stackedWidgetPage1.setObjectName(_fromUtf8("stackedWidgetPage1"))
        self.checkBox_2 = QtGui.QCheckBox(self.stackedWidgetPage1)
        self.checkBox_2.setGeometry(QtCore.QRect(20, 50, 91, 17))
        self.checkBox_2.setText(QtGui.QApplication.translate("Dialog", "Hot Dog   $5", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_2.setObjectName(_fromUtf8("checkBox_2"))
        self.checkBox_3 = QtGui.QCheckBox(self.stackedWidgetPage1)
        self.checkBox_3.setGeometry(QtCore.QRect(20, 80, 141, 17))
        self.checkBox_3.setText(QtGui.QApplication.translate("Dialog", "Chicken Burger  $10", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_3.setObjectName(_fromUtf8("checkBox_3"))
        self.checkBox = QtGui.QCheckBox(self.stackedWidgetPage1)
        self.checkBox.setGeometry(QtCore.QRect(20, 20, 111, 17))
        self.checkBox.setText(QtGui.QApplication.translate("Dialog", "Pizza   $25", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox.setObjectName(_fromUtf8("checkBox"))
        self.stackedWidget.addWidget(self.stackedWidgetPage1)
        self.stackedWidgetPage2 = QtGui.QWidget()
        self.stackedWidgetPage2.setObjectName(_fromUtf8("stackedWidgetPage2"))
        self.radioButton_6 = QtGui.QRadioButton(self.stackedWidgetPage2)
        self.radioButton_6.setGeometry(QtCore.QRect(20, 50, 111, 17))
        self.radioButton_6.setText(QtGui.QApplication.translate("Dialog", "Cold Drink  $10", None, QtGui.QApplication.UnicodeUTF8))
        self.radioButton_6.setObjectName(_fromUtf8("radioButton_6"))
        self.radioButton_5 = QtGui.QRadioButton(self.stackedWidgetPage2)
        self.radioButton_5.setGeometry(QtCore.QRect(20, 80, 82, 17))
        self.radioButton_5.setText(QtGui.QApplication.translate("Dialog", "Coffee  $5", None, QtGui.QApplication.UnicodeUTF8))
        self.radioButton_5.setObjectName(_fromUtf8("radioButton_5"))
        self.radioButton_4 = QtGui.QRadioButton(self.stackedWidgetPage2)
        self.radioButton_4.setGeometry(QtCore.QRect(20, 20, 82, 17))
        self.radioButton_4.setText(QtGui.QApplication.translate("Dialog", "Juice  $15", None, QtGui.QApplication.UnicodeUTF8))
        self.radioButton_4.setObjectName(_fromUtf8("radioButton_4"))
        self.stackedWidget.addWidget(self.stackedWidgetPage2)
        self.stackedWidgetPage3 = QtGui.QWidget()
        self.stackedWidgetPage3.setObjectName(_fromUtf8("stackedWidgetPage3"))
        self.checkBox_14 = QtGui.QCheckBox(self.stackedWidgetPage3)
        self.checkBox_14.setGeometry(QtCore.QRect(30, 40, 111, 17))
        self.checkBox_14.setText(QtGui.QApplication.translate("Dialog", "StrawBerry  $7", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_14.setObjectName(_fromUtf8("checkBox_14"))
        self.checkBox_12 = QtGui.QCheckBox(self.stackedWidgetPage3)
        self.checkBox_12.setGeometry(QtCore.QRect(30, 10, 81, 17))
        self.checkBox_12.setText(QtGui.QApplication.translate("Dialog", "Vanilla  $5", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_12.setObjectName(_fromUtf8("checkBox_12"))
        self.checkBox_11 = QtGui.QCheckBox(self.stackedWidgetPage3)
        self.checkBox_11.setGeometry(QtCore.QRect(30, 70, 101, 17))
        self.checkBox_11.setText(QtGui.QApplication.translate("Dialog", "Pineapple  $8", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_11.setObjectName(_fromUtf8("checkBox_11"))
        self.checkBox_13 = QtGui.QCheckBox(self.stackedWidgetPage3)
        self.checkBox_13.setGeometry(QtCore.QRect(30, 100, 111, 17))
        self.checkBox_13.setText(QtGui.QApplication.translate("Dialog", "Chocolate  $10", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_13.setObjectName(_fromUtf8("checkBox_13"))
        self.stackedWidget.addWidget(self.stackedWidgetPage3)
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 30, 91, 16))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Select Category", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setObjectName(_fromUtf8("label"))
        self.comboBox = QtGui.QComboBox(Dialog)
        self.comboBox.setGeometry(QtCore.QRect(140, 30, 69, 22))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))

        self.retranslateUi(Dialog)
        self.stackedWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        pass

