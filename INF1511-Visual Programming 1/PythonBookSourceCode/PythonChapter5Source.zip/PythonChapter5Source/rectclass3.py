class rect: 
	l=8 
	b=5
	def rectarea(self):
		return rect.l * rect.b
r=rect()
print ("Area of rectangle is ", r.rectarea())
