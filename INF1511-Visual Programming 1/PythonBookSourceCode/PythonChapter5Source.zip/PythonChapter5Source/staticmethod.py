class rect:
	@staticmethod
	def disp_message():
			l=50
			print ("Length is ", l)
	   
rect.disp_message()
r=rect()
r.disp_message()
