class rect: 
	l=8 
	b=5

print ("Length is %d, Breadth is %d" %(rect.l, rect.b))
print ("Class name is ", rect.__name__, " and Base class is ",rect.__bases__)
print ("Attributes of this class are ", rect.__dict__)
