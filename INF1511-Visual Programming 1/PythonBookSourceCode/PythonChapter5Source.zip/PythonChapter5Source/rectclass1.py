class rect: 
	l=8
	b=5
print ("Length is %d, Breadth is %d" %(rect.l, rect.b))
